package com.example.fianl_java_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class RegisterActivity_MORE extends AppCompatActivity {

    private EditText et_email, et_card, et_brith;
    private Button btn_done;

    @Override
    protected void onCreate(Bundle savedInstanceState) { // 액티비티 실행될때 처음으로 시작되는 애들
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_more);

        // 아이디 값 찾아주기
        et_email = findViewById(R.id.et_email);
        et_card = findViewById(R.id.et_card);
        et_brith = findViewById(R.id.et_brith);

        // 회원가입 버튼 클릭 시 수행
        btn_done = findViewById(R.id.btn_done);
        btn_done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 얘네는 Edittext에 현재 입력되어있는 값을 가져온다.

                String userEmail = et_email.getText().toString();
                String cardNum = et_card.getText().toString();
                String userBrith = et_brith.getText().toString();
                String userName = ((RegisterActivity)RegisterActivity.a).userName;
                String userPhone = ((RegisterActivity)RegisterActivity.a).userPhone;
                String userID = ((RegisterActivity_ALREADY)RegisterActivity_ALREADY.b).userID;
                String userPassword = ((RegisterActivity_ALREADY)RegisterActivity_ALREADY.b).userPassword;

                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean success = jsonObject.getBoolean("success");
                            if(success){ // 회원등록 성공
                                Toast.makeText(getApplicationContext(), "회원 등록에 성공하셨습니다.", Toast.LENGTH_SHORT).show();
                                // 다시 로그인 화면으로 넘어가는 코드
                                Intent intent = new Intent(RegisterActivity_MORE.this, MainActivity.class);
                                startActivity(intent);
                            }
                            else { // 실패
                                Toast.makeText(getApplicationContext(), "회원 등록에 실패하셨습니다.", Toast.LENGTH_SHORT).show();
                                return;
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                };
                // 서버로 발리를 이용해서 요청함.
                RegisterRequest_MORE registerRequest_more = new RegisterRequest_MORE(userID, userPassword, userName, userEmail, cardNum, userBrith, userPhone,responseListener);
                RequestQueue queue = Volley.newRequestQueue(RegisterActivity_MORE.this);
                queue.add(registerRequest_more);
            }
        });
    }
}