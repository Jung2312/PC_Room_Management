package com.example.fianl_java_app;

import com.journeyapps.barcodescanner.CaptureActivity;

public class Capture2 extends CaptureActivity {
}
