package com.example.fianl_java_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class IDPW_Search extends AppCompatActivity {

    public String userName, userPhone, userID, userPassword;
    private EditText et_name, et_phone;
    public static Context c;
    private Button btn_next1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_idpw_search);

        et_name = findViewById(R.id.et_name);
        et_phone = findViewById(R.id.et_phone);

        c = this;

        btn_next1 =findViewById(R.id.btn_next1);
        btn_next1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 얘네는 Edittext에 현재 입력되어있는 값을 가져온다.
                userName = et_name.getText().toString();
                userPhone = et_phone.getText().toString();

                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean success = jsonObject.getBoolean("success");
                            if(!success){ // 회원등록 성공
                                // 다시 로그인 화면으로 넘어가는 코드

                                Intent intent = new Intent(IDPW_Search.this, IDPW_Search_FInd.class);
                                userID = jsonObject.getString("userID");
                                userPassword = jsonObject.getString("userPassword");
                                startActivity(intent);
                            }
                            else { // 실패
                                Toast.makeText(getApplicationContext(), "해당 정보에는 계정이 없습니다", Toast.LENGTH_SHORT).show();
                                return;
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                };
                // 서버로 발리를 이용해서 요청함.
                SearchRequest registerRequest = new SearchRequest(userName, userPhone,responseListener);
                RequestQueue queue = Volley.newRequestQueue(IDPW_Search.this);
                queue.add(registerRequest);
            }
        });
    }
}