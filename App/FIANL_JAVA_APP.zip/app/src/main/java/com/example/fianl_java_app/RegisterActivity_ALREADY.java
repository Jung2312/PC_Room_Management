package com.example.fianl_java_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class RegisterActivity_ALREADY extends AppCompatActivity {

    public String userID, userPassword;
    private EditText et_id, et_pass;
    public static Context b;
    private Button btn_next2, btn_check;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_already);

        et_id = findViewById(R.id.et_id);
        et_pass = findViewById(R.id.et_pass);

        b = this;

        btn_check =findViewById(R.id.btn_check);
        btn_check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 얘네는 Edittext에 현재 입력되어있는 값을 가져온다.
                userID = et_id.getText().toString();

                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean success = jsonObject.getBoolean("success");
                            if(success){ // 회원등록 성공
                                Toast.makeText(getApplicationContext(), "사용 가능한 아이디입니다.", Toast.LENGTH_SHORT).show();
                                // 다시 로그인 화면으로 넘어가는 코드
                                btn_next2.setEnabled(true);
                            }
                            else { // 실패
                                Toast.makeText(getApplicationContext(), "이미 계정이 존재합니다", Toast.LENGTH_SHORT).show();
                                btn_next2.setEnabled(false);
                                return;
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                };
                // 서버로 발리를 이용해서 요청함.
                RegisterRequest_ALREADY registerRequest_already = new RegisterRequest_ALREADY(userID, responseListener);
                RequestQueue queue = Volley.newRequestQueue(RegisterActivity_ALREADY.this);
                queue.add(registerRequest_already);
            }
        });

        btn_next2 = findViewById(R.id.btn_next2);
        btn_next2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                userPassword = et_pass.getText().toString();
                Intent intent = new Intent(RegisterActivity_ALREADY.this, RegisterActivity_MORE.class);
                startActivity(intent);
            }
        });
    }
}