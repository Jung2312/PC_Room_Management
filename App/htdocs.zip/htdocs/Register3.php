<?php
    error_reporting(E_ALL);

    ini_set('display_errors', '1');
    $con = mysqli_connect("url", "root", "pw", "PC");
    mysqli_query($con,'SET NAMES utf8');
    

    if(isset($_POST["userID"]) || isset($_POST["userPassword"]) || isset($_POST["userName"]) || isset($_POST["userEmail"]) || isset($_POST["cardNum"]) || isset($_POST["userBrith"]) || isset($_POST["userPhone"])){
        $userID = $_POST["userID"];
        $userPassword = $_POST["userPassword"];
        $userName = $_POST["userName"];
        $userEmail = $_POST["userEmail"];
        $cardNum = $_POST["cardNum"];
        $userBrith = $_POST["userBrith"];
        $userPhone = $_POST["userPhone"];
    }
    
    $statement = mysqli_prepare($con, "INSERT INTO user (userID, userPassword, userName, userEmail, cardNum, userBrith, userPhone) VALUES (?,?,?,?,?,?,?)");
    mysqli_stmt_bind_param($statement, "sssssss", $userID, $userPassword, $userName, $userEmail, $cardNum, $userBrith, $userPhone);
    mysqli_stmt_execute($statement);


    $response = array();
    $response["success"] = true; 
 
    echo json_encode($response);
    


?>