<?php
    error_reporting(E_ALL);

    ini_set('display_errors', '1');
    $con = mysqli_connect("url", "root", "pw", "PC");
    mysqli_query($con,'SET NAMES utf8');

    
    if(isset($_POST["userID"]) || isset($_POST["userPassword"])){
        $userID = $_POST["userID"];
        $userPassword = $_POST["userPassword"];
    }
    

    $statement = mysqli_prepare($con, "SELECT * FROM user WHERE userID = ? AND userPassword = ?");
    mysqli_stmt_bind_param($statement, "ss", $userID, $userPassword);
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $userNum, $userID, $userPassword, $userName, $userEmail, $cardNum, $userBrith, $userPhone, $userAccumuate ,$LoginCheck);

    $response = array();
    $response["success"] = false;
 
    while(mysqli_stmt_fetch($statement)) {
        $response["success"] = true;
        $response["userID"] = $userID;
        $response["userPassword"] = $userPassword;
        $response["userName"] = $userName;
        $response["userBrith"] = $userBrith;        
    }
    
    $statement = mysqli_prepare($con, "UPDATE user SET loginCheck = 1 WHERE userID = ? AND userPassword = ?");
    mysqli_stmt_bind_param($statement, "ss", $userID, $userPassword);
    mysqli_stmt_execute($statement);    

    echo json_encode($response);


?>